﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 图书
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            comboBox1.Items.Add("经济管理");
            comboBox1.Items.Add("文化教育");
            comboBox1.Items.Add("实用艺术");
            comboBox1.Items.Add("科技科普");
            comboBox1.Items.Add("医药卫生");
            comboBox1.Items.Add("计算机");
            comboBox1.Items.Add("实用生活");
        }
        public string str = "";
        public string[] spiltstrings = new string[10];
        public string[] shujuku = new string[100000];
        public int a = 0;
        private void Form4_Load(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(@"D:\c#\图书2\常用图书目录.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs, Encoding.GetEncoding("GB2312"));
            do
            {
                str = sr.ReadLine();
                spiltstrings = str.Split('\t');
                str = "";
                for (int i = 0; i < spiltstrings.Length; i++)
                    str += spiltstrings[i] + "|" + "         ";
                listBox1.Items.Add(str);
                shujuku[a] = str;
                a++;
            }
            while (!sr.EndOfStream);
            sr.Close();
            fs.Close();
            a = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > 0)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "" && comboBox2.Text != "" && textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                string str = "";
                str = comboBox1.Text + "|  \t" + comboBox2.Text + "|  \t" + textBox1.Text + "|  \t" + textBox2.Text + "|  \t" + textBox3.Text;
                listBox1.Items.Add(str);
                MessageBox.Show("书籍已添加");
            }
            else
            {
                MessageBox.Show("书籍信息未填写完整！", "警告");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否保存图书信息?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                listBox1.Items.RemoveAt(0);
            FileStream fs = new FileStream(@"D:\c#\图书\常用图书目录.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter sw = new StreamWriter(fs,Encoding.GetEncoding("GB2312"));
            foreach (string item in listBox1.Items)
            {
                sw.WriteLine(item);
            }
            sw.Close();
            fs.Close();   
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            if (comboBox1.Text== "经济管理")
            {
                comboBox2.Items.Add("理财");
                comboBox2.Items.Add("其他");
            }
            else if (comboBox1.Text == "文化教育")
            {
                comboBox2.Items.Add("文化理论");
                comboBox2.Items.Add("励志（礼仪修养 职场");
                comboBox2.Items.Add("旅游"); 
                comboBox2.Items.Add("体育");
                comboBox2.Items.Add("学前幼儿教育");
                comboBox2.Items.Add("初等教育");
                comboBox2.Items.Add("中等教育");
                comboBox2.Items.Add("高等教育");
                comboBox2.Items.Add("语言");
                comboBox2.Items.Add("少儿读物");
                comboBox2.Items.Add("其他");
            }
            else if (comboBox1.Text == "实用艺术")
            { 
                comboBox2.Items.Add("工艺美术");
                comboBox2.Items.Add("色谱");
            }
            else if( comboBox1.Text =="计算机")
            { 
                comboBox2.Items.Add("图形图像 多媒体");
                comboBox2.Items.Add("计算机");
                comboBox2.Items.Add("硬件 外部设备 维修");
                comboBox2.Items.Add("操作系统/系统开发");
                comboBox2.Items.Add("程序设计");
                comboBox2.Items.Add("网络与数据通信");
                comboBox2.Items.Add("图形图像 多媒体");
                comboBox2.Items.Add("CAD CAM CAE");
                comboBox2.Items.Add("家庭与办公室用书");
                comboBox2.Items.Add("电脑杂志—合订本");
                comboBox2.Items.Add("数码全攻略");
                comboBox2.Items.Add("五笔字型");
                comboBox2.Items.Add("教材");
                comboBox2.Items.Add("其他");
            }
            else if (comboBox1.Text == "科技科普")
            {
                comboBox2.Items.Add("科技专著"); 
                comboBox2.Items.Add("科普");
                comboBox2.Items.Add("科幻");
            }
            else if (comboBox1.Text == "医药卫生")
            {
                comboBox2.Items.Add("专著");
                comboBox2.Items.Add("养生食疗");
                comboBox2.Items.Add("美容");
                comboBox2.Items.Add("心理");
                comboBox2.Items.Add("孕产育儿");
                comboBox2.Items.Add("常识");
            }
                 else if (comboBox1.Text == "实用生活")
            { 
                comboBox2.Items.Add("烹饪");
                comboBox2.Items.Add("编织");
                comboBox2.Items.Add("花卉园艺");
                comboBox2.Items.Add("时尚休闲");
                comboBox2.Items.Add("家居");
                comboBox2.Items.Add("其他");
                 }
          
        }
    }
}
