﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace 图书
{
    public partial class Form2 : Form
    {
        public static Form2 f = null;
        public string[] str2 = new string[100];
        public int i = 0;
        public Form2()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            label2.Text = "欢迎使用图书管理系统！！ 书籍是人类进步的阶梯！！";
            label2.Height = 100;
            label2.BackColor = Color.Transparent;
            label2.ForeColor = Color.Red  ;
            timer2.Interval = 100;
            timer2.Enabled = true;
            f = this;
            comboBox1.Items.Add("经济管理");
            comboBox1.Items.Add("文化教育");
            comboBox1.Items.Add("实用艺术");
            comboBox1.Items.Add("科技科普");
            comboBox1.Items.Add("医药卫生");
            comboBox1.Items.Add("计算机");
            comboBox1.Items.Add("实用生活");

            comboBox2.Items.Add("文化理论");
            comboBox2.Items.Add("励志（礼仪修养 职场");
            comboBox2.Items.Add("旅游");
            comboBox2.Items.Add("体育");
            comboBox2.Items.Add("学前幼儿教育");
            comboBox2.Items.Add("初等教育");
            comboBox2.Items.Add("中等教育");
            comboBox2.Items.Add("高等教育");
            comboBox2.Items.Add("语言");
            comboBox2.Items.Add("少儿读物");
            comboBox2.Items.Add("工艺美术");
            comboBox2.Items.Add("图形图像 多媒体");
            comboBox2.Items.Add("色谱");
            comboBox2.Items.Add("科技专著");
            comboBox2.Items.Add("科普");
            comboBox2.Items.Add("科幻");
            comboBox2.Items.Add("专著");
            comboBox2.Items.Add("美容");
            comboBox2.Items.Add("心理");
            comboBox2.Items.Add("孕产育儿");
            comboBox2.Items.Add("计算机");
            comboBox2.Items.Add("硬件 外部设备 维修");
            comboBox2.Items.Add("操作系统/系统开发");
            comboBox2.Items.Add("程序设计");
            comboBox2.Items.Add("网络与数据通信");
            comboBox2.Items.Add("图形图像 多媒体");
            comboBox2.Items.Add("数码全攻略");
            comboBox2.Items.Add("五笔字型");
            comboBox2.Items.Add("计算机");
            comboBox2.Items.Add("烹饪");
            comboBox2.Items.Add("编织");
            comboBox2.Items.Add("花卉园艺");
            comboBox2.Items.Add("时尚休闲");
            comboBox2.Items.Add("常识");
            comboBox2.Items.Add("家居");
            comboBox2.Items.Add("其他");
            timer1.Start();
        }
        public string[] spiltstrings = new string[10];
        public string str = "";
        public int a = 0;
        public string[]shujuku=new string[100000];
        public string[] shu=new string[100000];
        public string []lend =new string[100];
        public string []returns=new string[100];
        private void Form2_Load(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(@"D:\c#\图书2\常用图书目录.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs,Encoding.GetEncoding("GB2312"));
            do
            {
                str = sr.ReadLine();
                spiltstrings = str.Split('\t');
                str = "";
                for (int i = 0; i < spiltstrings.Length; i++)
                    str += spiltstrings[i]+"|"+"         ";
                    listBox1.Items.Add(str);
                    shujuku[a] = str;
                    a++;
            }
            while (!sr.EndOfStream);
            sr.Close();
            fs.Close();
            a = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (string i in shujuku)
            {
                if (!string.IsNullOrEmpty(i))
                {
                    if (i.Contains(comboBox1.Text)&&i.Contains(comboBox2.Text)&&i.Contains (textBox1 .Text ))
                        shu[a] = i;
                    a++;
                }
            }
            foreach (string i in shu)
                if (!string.IsNullOrEmpty(i))
                    listBox1.Items.Add(i);
            for (int i = 0; i < shu.Length; i++)
                shu[i] = ""; 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > 0)
            {
                returns[i]= DateTime.Now.AddDays(7).ToString();
                str2[i] = listBox1.SelectedItem.ToString() + DateTime.Now.ToString() + "\t"+DateTime.Now.AddDays(7).ToString();
            }
            else
                MessageBox.Show("未选中图书！", "提示");
            i++;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = DateTime.Now.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Close();
        }
        


        private void timer2_Tick_1(object sender, EventArgs e)
        {
            label2.Location = new Point(label2.Location.X - 10, 0);
            if (label2.Left <= -label2.Width)
            {
                label2.Left = panel1.ClientRectangle.Width + 10;
            }
        }

        private void label2_MouseEnter_1(object sender, EventArgs e)
        {
            timer2.Stop();
        }

        private void label2_MouseLeave_1(object sender, EventArgs e)
        {
            timer2.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox1.Text = "";
        }

    
    }

}
