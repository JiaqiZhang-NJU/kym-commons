﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            label1.Text = "欢迎使用图书管理系统！！ 知识就是力量！！";
            label1.Height = 100;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = Color.Red;
            timer2.Interval = 100;
            timer2.Enabled = true;
                foreach (string i in Form2.f.str2)
                {
                    if (!string.IsNullOrEmpty(i))
                    {
                        listBox1.Items.Add(i);
                    }
                }
                toolStripStatusLabel1.Text = "";
        }
        public string str = "";
        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >0)
            {
                Form2.f.str2[listBox1.SelectedIndex] = "";
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);                
                MessageBox.Show("已归还");
            }
            else
            { MessageBox.Show("未选中图书"); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2.f.Show(); 
            this.Close();
        }
 
        private void button3_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex>=0)
                timer1.Start();
            else
                MessageBox.Show("请选中查看书籍！");
        }

        //输入月份后获得该月天数
        private int GetDay(int year, int month)
        {
            int result = 31;
            switch (month)                           
            {
                case 4:
                case 6:
                case 9:
                case 11:
                    result = 30;
                    break;
                case 2:
                    if ((year % 100 != 0) && (year% 4 == 0) || (year% 400 == 0))
                    {
                        result = 29;
                    }
                    else
                    {
                        result = 28;
                    }
                    break;
            }
            return result;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                DateTime observeTime = DateTime.Parse(Form2.f.returns[listBox1.SelectedIndex-1]);//倒计时日期
                DateTime now = DateTime.Now.AddDays(1);    //当前时间
                TimeSpan ts = observeTime.Subtract(now);    //两个时间之差
                StringBuilder result = new StringBuilder();   //存放结果
                int year = observeTime.Year - now.Year;       //得到相差的年
                int month = observeTime.Month - now.Month;  //得到相差的月
                int day = observeTime.Day - now.Day;        //得到相差的日
                int hmh = (observeTime.Hour - now.Hour) * 3600 + (observeTime.Minute - now.Minute) * 60 + (observeTime.Second - now.Second);
                //如果时分秒比现在的时间晚
                if (hmh <= 0)
                {
                    //向日借一
                    day--;
                    if ((day <= 0 && month > 0) || (day <= 0 && year > 0))
                    {
                        //如果天数小于0向月借一
                        day = GetDay(now.Year, now.Month) - now.Day + observeTime.Day;
                        month--;
                        if (month < 0 && year > 0)
                        {
                            //如果月数小于0，向年借一，同时把月专为正数
                            month += 12;
                            year--;
                        }
                    }
                }
                //如果天数小于0向月借一
                if ((day < 0 && month > 0) || (day < 0 && year > 0))
                {
                    day = GetDay(now.Year, now.Month) - now.Day + observeTime.Day;
                    month--;
                    if (month < 0 && year > 0)
                    {
                        //如果月数小于0，向年借一，同时把月专为正数
                        month += 12;
                        year--;
                    }
                }
                //如果月数小于0，向年借一，同时把月专为正数
                if (month < 0 && year > 0)
                {
                    month += 12;
                    year--;
                }

                if (year < 0 || (year == 0 && month < 0) || (year == 0 && month == 0 && day < 0))
                {
                    str = "\t" + "已超过日期";
                    return;
                }

                if (year > 0)
                {
                    result.Append(year + "年");
                }
                if (month > 0)
                {
                    result.Append(month + "月");
                }
                if (day > 0)
                {
                    result.Append(day + "天");
                }
                if (ts.Hours > 0)
                {
                    result.Append(ts.Hours + "时");
                }
                if (ts.Minutes > 0)
                {
                    result.Append(ts.Minutes + "分");
                }
                if (ts.Seconds > 0)
                {
                    result.Append(ts.Seconds + "秒");
                }
                if (result.Length == 0)
                {
                    result.Append("已超过日期");
                }
                toolStripStatusLabel1.Text = result.ToString();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            label1.Location = new Point(label1.Location.X - 10, 0);
            if (label1.Left <= -label1.Width)
            {
                label1.Left = panel1.ClientRectangle.Width + 10;
            }
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            timer2.Stop();
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            timer2.Start();
        }

    }        
}
