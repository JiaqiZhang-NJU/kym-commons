﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace 图书
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked == true )
            {
                new Form2().Show();
                this.Hide();
            }
                else if(radioButton2.Checked == true)
                {
                    new Form4().Show();
                    this.Hide();
                }
            else
            { MessageBox.Show("未选择登录身份"); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否退出应用程序?","提示",MessageBoxButtons .YesNo ,MessageBoxIcon .Question  );
            if (result == DialogResult.Yes)
            { 
                Application.Exit(); 
            }
        }
    }
}
